document.addEventListener("DOMContentLoaded", () => {
    const calcBtn = document.getElementById("calc-btn");
    if (calcBtn) {
        calcBtn.addEventListener("click", () => {
            const modelSelect = document.getElementById("tomos-model").value;
            const outputDiv = document.getElementById("calc-output");
            
            let infoText = "";
            outputDiv.classList.add("success-box");
            outputDiv.style.display = "block";

            switch(modelSelect) {
                case "apn6":
                    infoText = "APN 6: Legendarni mopedi s 4-stopenjskim menjalnikom, proizvedeni v Kopru. Prostornina: 49 ccm.";
                    break;
                case "t15":
                    infoText = "Tomos T15 SLC: Športni model z močnejšim agregatom in petimi prestavami, sanje mladine v 80. letih.";
                    break;
                case "colibri":
                    infoText = "Colibri: Prvi Tomosovi mopedi, ki so začeli zgodbo o uspehu na slovenskih cestah.";
                    break;
                default:
                    infoText = "Izberite veljaven model za prikaz podatkov.";
            }
            outputDiv.textContent = infoText;
        });
    }

    const form = document.getElementById("povpraševanje-form");
    if (form) {
        form.addEventListener("submit", (event) => {
            event.preventDefault(); 

            const imeInput = document.getElementById("ime");
            const emailInput = document.getElementById("email");
            const modelInput = document.getElementById("model-izbira");
            
            const imeError = document.getElementById("ime-error");
            const emailError = document.getElementById("email-error");
            const successBox = document.getElementById("form-success");

            let isValid = true;

            if (imeInput.value.trim() === "") {
                imeError.textContent = "Prosimo, vnesite vaše ime in priimek.";
                imeError.classList.add("visible");
                isValid = false;
            } else {
                imeError.classList.remove("visible");
            }

            if (emailInput.value.trim() === "" || !emailInput.value.includes("@")) {
                emailError.textContent = "Vnesite veljaven e-poštni naslov.";
                emailError.classList.add("visible");
                isValid = false;
            } else {
                emailError.classList.remove("visible");
            }

            if (isValid) {
                successBox.textContent = `Hvala, ${imeInput.value.trim()}! Vaše povpraševanje za model ${modelInput.value} je bilo uspešno oddano. Odgovorili vam bomo v najkrajšem možnem času.`;
                successBox.style.display = "block";
                successBox.classList.add("success-box");
                
                form.reset();
            }
        });
    }
});